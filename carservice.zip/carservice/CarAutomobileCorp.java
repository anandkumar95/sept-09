package carservice;

import java.sql.SQLException;
import java.util.Scanner;

public class CarAutomobileCorp {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		JdbcCarAuto jdbc = new JdbcCarAuto();
		jdbc.getConnection();
		
		Scanner carinput = new Scanner(System.in);
		String flag = "";
		
		do {
			System.out.println("Welcome to Car Automobile Corportation!");
			System.out.println("---------------------------------------------");
			System.out.println("Menu");
			System.out.println("---------------------------------------------");
			System.out.println("1: Enter the new request\n2: Update a car repair status\n3: Display report");
			
			System.out.println("Please enter your choice");
			int ch = carinput.nextInt();
			
			switch(ch) {
			case 1: 
				jdbc.insertRecord();
				break;
			}
			
			flag = carinput.nextLine();
		}while(flag.equalsIgnoreCase("yes")); 
	}

}
