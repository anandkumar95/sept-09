package carservice;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class JdbcCarAuto {
	
	Connection con; 
	PreparedStatement ps;
	
	public void getConnection() throws ClassNotFoundException, SQLException 
	{
		String path= "jdbc:oracle:thin:@localhost:1521:XE";
		String username= "system";
		String password= "admin";
		
		Class.forName("oracle.jdbc.driver.OracleDriver");
		con= DriverManager.getConnection(path,username,password);
	}
	
	public void insertRecord()throws SQLException
	{
		Scanner carinput = new Scanner(System.in);
		
		System.out.println("\nPlease Enter Your Name: ");
		String name = carinput.nextLine();
		
		System.out.println("\nPlease Enter Your Car Registration Number: ");
		String regnumber = carinput.nextLine();
		
		System.out.println("\nPlease enter Car repairing date (DD/FIRST_THREE_CHAR_OF_MONTH/YY): ");
		String repairdate = carinput.nextLine();
		
		System.out.println("\nPlease Enter the problems you are facing in your car: ");
		String problem = carinput.nextLine();
		
		String flag = "pending";
		
		String query = "insert into RepairCar(CustomerName,RegistrationNo,RepairingDate,issue,flagstatus) values (?,?,?,?,?)";
		ps = con.prepareStatement(query);
		
		ps.setString(1, name);
		ps.setString(2,regnumber);
		ps.setString(3, repairdate);
		ps.setString(4,problem);
		ps.setString(5,flag);
		
		
		System.out.println("\nPress 1 to submit\nPress 2 to exit");
		int insert = carinput.nextInt();
		
		if(insert == 1) {
			ps.executeUpdate();
			System.out.println("\nRecord insertion was successful.");
		}
		else {
			System.out.println("\nRecord insertion was discarded.");
			System.exit(0);
		}
		
		carinput.close();
		
	}
}
